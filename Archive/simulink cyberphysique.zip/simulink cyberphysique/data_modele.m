tau = 0.02;
k = 50;

a = -1/tau;
b = k/tau;

ar = [a 0; -1 0];
br = [b;0];

% Calcul retour d'état à la main pour les pôles -50 et -60
% k1 = 3000/2500;
% k2 = (50-110)/2500;

% Calcul retour d'état automatisé
vp_a = eig(a);
triple_vp_a = 3*vp_a;
vp_desirees = [vp_a triple_vp_a];
K = place(ar, br, vp_desirees);
k1 = K(1, 2);
k2 = K(1, 1);

% Calcul paramètres observateur
A0 = [a 0;1 0];
B0 = [b;0];
C0 = [0 1];
vpo_desirees = [5*vp_a 6*vp_a];

Lt = place(transpose(A0), transpose(C0), vpo_desirees);
L = transpose(Lt);